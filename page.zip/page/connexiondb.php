<?php

$dbhost='localhost';
$dbname='freelance';
$dbuser='root';
$dbpass='';

try {
	$db= new PDO('mysql:host='.$dbhost.'; dbname='.$dbname,$dbuser,$dbpass);
	$db->exec('USE freelance');
	


	
} catch (PDOException $e) {
	print('Une erreur est subvenue dans la base de donnée'.$e->getMessage());
	
}

?>
