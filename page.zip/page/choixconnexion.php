<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Freelance</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<header class="conn-header">
		<ul class="headerc">
			
			<li class="m3"> <img class="img3" src="../img/account.png"> CONNEXION</li>
			<li class="m4"><a href="../index.php"><img class="img3"  src="../img/logout.png"></a> </li>
			
        </ul>




	</header>
	<div class="choixcon">
		<section>
			<div class="m">
				<img  class="image" src="../img/u.png">

			</div>
			

		<span class="title"> FREELANCE </span>   <br><br>

		<em class="content1">   Je suis freelance </em><br><br>

		<a href="connexion.php"> <button class="bouton"> JE ME CONNECTE </button></a>


	    </section>

	    <section>
	    	<div class="m">
	    		<img  class="image" src="../img/b.jpg">

	    	</div>
	    	

		<span class="title"> CLIENT</span>   <br><br>

		<em class="content1"> Je suis un client </em> <br><br>

		<a href="connexion.php"> <button class="bouton"> JE ME CONNECTE </button></a>


	    </section>

	    <section>
	    	<div class="m">
	    		<img  class="image" src="../img/a.png">

	    	</div>
	    	

		<span class="title"> PARTENAIRE</span>     <br><br>

		<em class="content1"> Je suis un partenaire </em><br><br>

		<a href="#"> <button class="bouton"> JE ME CONNECTE </button></a>


	    </section>






	</div>

	
</body>
</html>