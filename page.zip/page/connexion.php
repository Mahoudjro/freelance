<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Freelance</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body class="e">
    <div class="ee">
	<div class="formulaire1">
        <img src="../img/f.jpg"
        id="pro" 

        >
   
       
            <h2>Connexion</h2>
      <form id="signupForm1" class="eee">       
        
            <input type="email" id="email" name="email" placeholder="E-mail" required >
            
            <input type="password" id="password" name="password" placeholder="password" required>

           
                <button class="p">Se connecter</button>

           
            
       
       
        
    </form>
</div>
</div>


</body>
</html>