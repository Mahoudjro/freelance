<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Freelance</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body class="e">
	<div class="formulaire" >
        <?php
        include'connexiondb.php';


        if (isset($_POST['enregister'])) {
            // code...
            $nom = $_POST['fullname']; 
            $prenom = $_POST['fullpame'];  
            $Date = $_POST['Date'];     
            $email= $_POST['email'];     
            $password = $_POST['password']; 
            $preferences =$_POST['preferences'];

            if(!empty($nom) && !empty($Date) && !empty($email) && !empty($password) && !empty($preferences) ){
                $re = $db->prepare('INSERT INTO Users(Nom,Prenom , Date,Email , Mdp , preference ) VALUES(:nom,:Date,:email,:password,:preferences)');

                $re->bindvalue(':nom', $nom);
                $re->bindvalue(':Prenom', $Prenom);
                $re->bindvalue(':Date', $Date);
                $re->bindvalue(':email', $email);
                $re->bindvalue(':password', $password);
                $re->bindvalue(':preferences', $preferences);

                $result = $re->execute();
                if (!$result) {
                    // code...
                    echo "Un problème est survenue au cours de l'enrégistrement ";
                }else{

                    echo"
                    <script type=\"text/javascript\"> alert('Enrégister')</script>

                    ";
                }


            }else {
                // code...
                echo "Tout les champs sont requis ";
            }      
               }




        ?>
    <form id="signupForm" metode="post">
        <fieldset>
            <legend>Étape 1: Informations personnelles</legend>
            <label for="fullname">Nom :</label> <br> <br>
            <input type="text" id="fullname" name="fullname" required> <br> <br>

            <label for="fullname">Prénom:</label> <br> <br>
            <input type="text" id="fullname" name="fullpame" required> <br> <br>

            <label for="fullname">Date de naissance</label> <br> <br>
            <input type="date" id="fullname" name="fullname" required> <br> <br>
            <button class="next">Suivant</button>
        </fieldset>
       
        <fieldset>
            <legend>Étape 2: Informations de connexion</legend>
            <label for="email">Email:</label> <br> <br>
            <input type="email" id="email" name="email" required>
            <label for="password">Mot de passe:</label> <br> <br>
            <input type="password" id="password" name="password" required>
            <button class="prev">Précédent</button>
            <button class="next">Suivant</button>
        </fieldset>
       
        <fieldset>
            <legend>Étape 3: Préférences</legend>
            <label for="preferences">Préférences:</label> <br> <br>
            <textarea id="preferences" name="preferences" style=""></textarea> <br> <br>
            <button class="prev">Précédent</button>
            <button class="f" type="submit" name="enregister">Soumettre</button>
        </fieldset>
    </form>
</div>
<script type="text/javascript" src="../js/inscription.js"></script>

</body>
</html>