<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Freelance</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<div class="Modèle">
		<span class="n"> Talent as a Service :</span>
		<h2>Offre pour des grandes entreprises</h2>

		<p>Des solutions sécurisées pour connecter les meilleurs tealents
			externes aux besoins des grandes  organisation privées 
			et publiques 

        </p>
        <a href="contact.php"><button class="v">NOUS CONTACTER</button></a>
        


	</div>

</body>
</html>