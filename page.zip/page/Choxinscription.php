<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Freelance</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<div class="choix">
		<section>
			<div class="m">
				<img  class="image" src="../img/u.png">

			</div>
			

		<span class="title"> FREELANCE </span>   <br><br>

		<em class="content">   Je recherche des missions </em><br><br>

		<a href="Inscription.php"> <button class="bouton"> CREER MON PROFIL </button></a>


	    </section>

	    <section>
	    	<div class="m">
	    		<img  class="image" src="../img/b.jpg">

	    	</div>
	    	

		<span class="title"> CLIENT</span>   <br><br>

		<em class="content"> Je suis un grand compte </em> <br><br>

		<a href="inscription1.php"> <button class="bouton"> RECHERCHER DES FREELANCES </button></a>


	    </section>

	    <section>
	    	<div class="m">
	    		<img  class="image" src="../img/a.png">

	    	</div>
	    	

		<span class="title"> PARTENAIRE</span>     <br><br>

		<em class="content"> J'intègre un réseaux d'expert </em><br><br>

		<a href="contact.php"> <button class="bouton"> NOUS CONTACTER </button></a>


	    </section>






	</div>

	
</body>
</html>