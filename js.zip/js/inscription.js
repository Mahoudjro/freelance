document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('signupForm');
    const fieldsets = form.querySelectorAll('fieldset');
    let currentStep = 0;

    function showStep(step) {
        fieldsets.forEach((fieldset, index) => {
            if (index === step) {
                fieldset.style.display = 'block';
            } else {
                fieldset.style.display = 'none';
            }
        });
    }

    function nextStep() {
        if (currentStep < fieldsets.length - 1) {
            currentStep++;
            showStep(currentStep);
        }
    }

    function prevStep() {
        if (currentStep > 0) {
            currentStep--;
            showStep(currentStep);
        }
    }

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        // Insérer ici le code de traitement des données soumises
       
    });

    const nextButtons = document.querySelectorAll('.next');
    const prevButtons = document.querySelectorAll('.prev');

    nextButtons.forEach(button => {
        button.addEventListener('click', nextStep);
    });

    prevButtons.forEach(button => {
        button.addEventListener('click', prevStep);
    });
});