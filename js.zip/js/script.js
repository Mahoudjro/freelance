var logo = document.querySelector('.y');
var menu = document.querySelector('.menu');

logo.addEventListener('click',function(){
	menu.classList.toggle('showmenu')

});


